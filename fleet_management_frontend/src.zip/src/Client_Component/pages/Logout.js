import React from 'react';

const Logout = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h2>Logout</h2>
      <p>You are now logged out.</p>
    </div>
  );
};

export default Logout;
